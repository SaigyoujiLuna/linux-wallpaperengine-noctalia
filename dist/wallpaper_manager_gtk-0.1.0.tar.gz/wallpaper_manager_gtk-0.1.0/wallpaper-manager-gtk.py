#!/usr/bin/env python3
"""Compatibility launcher for the package-based application."""

from wallpaper_manager.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
