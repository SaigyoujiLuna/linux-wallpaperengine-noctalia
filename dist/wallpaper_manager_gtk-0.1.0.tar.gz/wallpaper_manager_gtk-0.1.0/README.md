# 壁纸管理器 GTK

基于 `linux-wallpaperengine` 的 GTK4 + libadwaita 壁纸管理器，现已重构为标准的 `uv` 管理 Python 项目，并按功能拆分为包内模块。

## 项目结构

- `wallpaper_manager/cli.py`：命令行入口与 `--startup` 分发
- `wallpaper_manager/startup.py`：会话启动时自动恢复上次壁纸
- `wallpaper_manager/config/`：常量与配置读写
- `wallpaper_manager/services/`：壁纸扫描、显示器检测、引擎与系统交互
- `wallpaper_manager/ui/mvi.py`：GUI 的 MVI 状态、Intent、Effect 与 Store
- `wallpaper_manager/ui/view_models.py`：列表行等 GTK 视图使用的 UI view-model
- `wallpaper_manager/ui/`：GTK 应用、窗口与列表行组件
- `wallpaper-manager-gtk.py`：兼容旧调用方式的薄启动脚本

## 依赖

系统依赖：

```bash
# Arch Linux
sudo pacman -S python-gobject gtk4 libadwaita

# Debian/Ubuntu
sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-4.0 gir1.2-adw-1
```

Python 依赖与虚拟环境由 `uv` 管理：

```bash
uv sync
```

## 运行

推荐直接使用 `uv` 暴露的脚本入口：

```bash
uv run wallpaper-manager-gtk
```

也可以使用模块入口：

```bash
uv run python -m wallpaper_manager
```

旧的顶层脚本仍可用：

```bash
uv run wallpaper-manager-gtk.py
```

## 启动恢复

登录会话启动时恢复上次壁纸：

```bash
uv run wallpaper-manager-gtk --startup
```

启动恢复过程中，CLI 会先等待 `noctalia-shell` 的 `wallpaper` IPC target 完全注册，再等待新的壁纸截图真正生成，最后轮询通知 shell 更新；这样既能避开会话启动顺序竞争，也能保证 shell 收到的路径始终可读取，而不是固定盲等。

## 桌面快捷方式

将桌面文件复制到本地应用目录：

```bash
cp wallpaper-manager-gtk.desktop ~/.local/share/applications/
```

## 配置文件

运行时配置与 shell 版本兼容，统一保存在：

```text
~/.config/wallpaper-manager/config
```

## niri 概览说明

应用会在切换壁纸后把最新壁纸截图发送给 `noctalia-shell`，由它自己的背景/概览 layer 同步到 niri 概览页。

现在在切换壁纸后，应用会：

- 等待截图生成，并通知 `noctalia-shell` 更新壁纸 layer 与配色
- 直接调用 `niri msg action do-screen-transition`

由于 `noctalia-shell` 的壁纸服务按“路径变化”触发切换，应用会为每次切换生成新的截图文件路径，确保概览页同步生效。
