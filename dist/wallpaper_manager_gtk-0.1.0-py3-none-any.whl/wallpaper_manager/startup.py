from __future__ import annotations

import sys
from pathlib import Path

from wallpaper_manager.config import load_config
from wallpaper_manager.config.constants import ENGINE_BIN
from wallpaper_manager.services.system import (
    launch_wallpaper,
    notify_noctalia_shell,
    resolve_monitor,
)


def startup_apply() -> int:
    """Apply the last used wallpaper for desktop-session startup."""
    config = load_config()
    wallpaper_dir = Path(config.last_wallpaper_dir).expanduser()

    if not config.we_install_dir or not config.last_wallpaper_dir:
        print(
            "wallpaper-manager: no wallpaper configured — run the GUI first.",
            file=sys.stderr,
        )
        return 1

    if not wallpaper_dir.is_dir():
        print(
            f"wallpaper-manager: wallpaper directory not found: {wallpaper_dir}",
            file=sys.stderr,
        )
        return 1

    monitor = resolve_monitor(config.last_monitor)
    if not monitor:
        print(
            "wallpaper-manager: no monitors detected (is wlr-randr installed?)",
            file=sys.stderr,
        )
        return 1

    return 0
