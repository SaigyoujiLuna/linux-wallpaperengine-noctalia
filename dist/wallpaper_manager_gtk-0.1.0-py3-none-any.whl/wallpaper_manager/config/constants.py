"""Global constants for the Wallpaper Manager GTK application."""

from pathlib import Path

APP_ID = "io.github.wallpaper-manager-gtk"
APP_NAME = "壁纸管理器"
ENGINE_SUBTITLE = "linux-wallpaperengine"
AUTO_MONITOR_LABEL = "自动检测"
CONFIG_DIR = Path("~/.config/wallpaper-manager").expanduser()
CONFIG_FILE = CONFIG_DIR / "config"
CACHE_DIR = Path("~/.cache/wallpaper-manager").expanduser()
WORKSHOP_SUBPATH = Path("steamapps/workshop/content/431960")
ASSETS_SUBPATH = Path("steamapps/common/wallpaper_engine/assets")
ENGINE_BIN = "linux-wallpaperengine"
THUMB_W = 128
THUMB_H = 72
SCALE_MODES = ("fill", "fit", "stretch", "default")
PREVIEW_NAMES = (
    "preview.gif",
    "preview.jpg",
    "preview.png",
    "preview.jpeg",
    "preview.webp",
)
