from __future__ import annotations

import threading

from wallpaper_manager.config.constants import THUMB_H, THUMB_W
from wallpaper_manager.gtk import Adw, Gdk, GLib, Gtk
from wallpaper_manager.ui.view_models import WallpaperRowModel


class WallpaperRow(Adw.ActionRow):
    def __init__(self, row_model: WallpaperRowModel):
        super().__init__()
        self.row_model = row_model
        self._build()
        if row_model.preview is not None:
            threading.Thread(
                target=self._load_thumb,
                args=(row_model.preview,),
                daemon=True,
            ).start()

    def _build(self) -> None:
        self.set_title(self.row_model.title)
        self.set_subtitle(self.row_model.wallpaper_type_label)

        self._thumb = Gtk.Picture()
        self._thumb.set_can_shrink(True)
        self._thumb.set_content_fit(Gtk.ContentFit.COVER)
        self._thumb.set_size_request(THUMB_W, THUMB_H)
        self.add_prefix(self._thumb)

    def _load_thumb(self, path) -> None:
        try:
            texture = Gdk.Texture.new_from_filename(str(path))
        except (GLib.Error, OSError):
            return
        GLib.idle_add(self._thumb.set_paintable, texture)

    def matches(self, query: str) -> bool:
        return self.row_model.matches(query)
