from wallpaper_manager.config.constants import APP_ID
from wallpaper_manager.gtk import Adw, Gio
from wallpaper_manager.ui.window import WallpaperManagerWindow


class WallpaperManagerApp(Adw.Application):
    def __init__(self):
        super().__init__(
            application_id=APP_ID,
            flags=Gio.ApplicationFlags.FLAGS_NONE,
        )
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.DEFAULT)

    def do_activate(self) -> None:
        windows = self.get_windows()
        if windows:
            windows[0].present()
            return
        window = WallpaperManagerWindow(self)
        window.present()
