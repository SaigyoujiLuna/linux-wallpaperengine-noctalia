from __future__ import annotations

from pathlib import Path

from wallpaper_manager.config.constants import (
    APP_NAME,
    AUTO_MONITOR_LABEL,
    ENGINE_SUBTITLE,
    SCALE_MODES,
)
from wallpaper_manager.gtk import Adw, Gio, GLib, Gtk
from wallpaper_manager.ui.mvi import (
    ApplySelectedWallpaper,
    ApplyWallpaper,
    RefreshMonitors,
    RefreshWallpapers,
    SearchChanged,
    SelectMonitor,
    SelectScaling,
    SelectWallpaper,
    ShowErrorEffect,
    SteamDirInputChanged,
    StartEngine,
    StopEngine,
    SubmitSteamDir,
    WallpaperStore,
    WallpaperViewState,
)
from wallpaper_manager.ui.rows import WallpaperRow
from wallpaper_manager.ui.view_models import WallpaperRowModel


class WallpaperManagerWindow(Adw.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title(APP_NAME)
        self.set_default_size(800, 600)
        self._rendering = False
        self._state = WallpaperViewState()
        self._rendered_wallpapers: tuple[WallpaperRowModel, ...] = ()
        self._rows_by_directory = {}
        self._monitor_model = Gtk.StringList.new([AUTO_MONITOR_LABEL])
        self._scale_model = Gtk.StringList.new(list(SCALE_MODES))
        self._string_expression = Gtk.PropertyExpression.new(
            Gtk.StringObject,
            None,
            "string",
        )
        self._build_ui()
        self._store = WallpaperStore(self._render, self._handle_effect)
        self._store.start()

    def _build_ui(self) -> None:
        toolbar_view = Adw.ToolbarView()
        self.set_content(toolbar_view)

        header = Adw.HeaderBar()
        header.set_title_widget(self._build_header_title())
        toolbar_view.add_top_bar(header)

        self._search_entry = Gtk.SearchEntry()
        self._search_entry.set_placeholder_text("搜索壁纸…")
        self._search_entry.connect("search-changed", self._on_search_changed)
        header.pack_start(self._search_entry)

        settings_button = Gtk.Button(label="设置")
        settings_button.connect("clicked", self._on_open_settings)
        header.pack_end(settings_button)

        self._start_btn = Gtk.Button(label="启动引擎")
        self._start_btn.connect("clicked", self._on_start_engine)
        header.pack_end(self._start_btn)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        clamp = Adw.Clamp()
        clamp.set_maximum_size(1100)
        clamp.set_tightening_threshold(800)
        clamp.set_child(root)
        toolbar_view.set_content(clamp)
        self._settings_dialog = self._build_settings_dialog()

        playback_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        playback_bar.set_margin_start(12)
        playback_bar.set_margin_end(12)
        playback_bar.set_margin_top(10)
        playback_bar.set_margin_bottom(10)
        root.append(playback_bar)

        monitor_label = Gtk.Label(label="显示器")
        monitor_label.add_css_class("dim-label")
        playback_bar.append(monitor_label)

        self._monitor_dropdown = Gtk.DropDown.new(
            self._monitor_model,
            self._string_expression,
        )
        self._monitor_dropdown.connect("notify::selected", self._on_monitor_changed)
        playback_bar.append(self._monitor_dropdown)

        refresh_monitors_button = Gtk.Button(label="刷新")
        refresh_monitors_button.connect("clicked", self._on_refresh_monitors)
        playback_bar.append(refresh_monitors_button)

        scale_label = Gtk.Label(label="缩放模式")
        scale_label.add_css_class("dim-label")
        playback_bar.append(scale_label)

        self._scale_dropdown = Gtk.DropDown.new(
            self._scale_model,
            self._string_expression,
        )
        self._scale_dropdown.connect("notify::selected", self._on_scale_changed)
        playback_bar.append(self._scale_dropdown)

        playback_bar.append(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL))

        overview_hint = Gtk.Label(label="niri 概览背景请在设置页中查看说明")
        overview_hint.add_css_class("dim-label")
        overview_hint.set_hexpand(True)
        overview_hint.set_xalign(0)
        playback_bar.append(overview_hint)

        root.append(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))

        scroll = Gtk.ScrolledWindow()
        scroll.set_overlay_scrolling(False)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        root.append(scroll)

        self._listbox = Gtk.ListBox()
        self._listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self._listbox.set_activate_on_single_click(False)
        self._listbox.set_filter_func(self._filter_func)
        self._listbox.add_css_class("boxed-list")
        self._listbox.connect("row-activated", self._on_row_activated)
        self._listbox.connect("row-selected", self._on_row_selected)
        scroll.set_child(self._listbox)

        placeholder = Adw.StatusPage(
            title="还没有可显示的壁纸",
            description="请先设置 Steam 安装目录，以加载已下载的壁纸列表。",
        )
        placeholder.set_icon_name("preferences-desktop-wallpaper-symbolic")
        self._listbox.set_placeholder(placeholder)

        root.append(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL))

        action_group = Adw.PreferencesGroup(title="当前状态")
        root.append(action_group)

        self._status_row = Adw.ActionRow(title="状态")
        self._status_row.set_subtitle("就绪")
        self._status_row.set_activatable(False)

        refresh_button = Gtk.Button(label="刷新列表")
        refresh_button.set_valign(Gtk.Align.CENTER)
        refresh_button.connect("clicked", self._on_refresh_wallpapers)
        self._status_row.add_prefix(refresh_button)

        stop_button = Gtk.Button(label="停止引擎")
        stop_button.set_valign(Gtk.Align.CENTER)
        stop_button.connect("clicked", self._on_stop_engine)
        self._status_row.add_suffix(stop_button)

        apply_button = Gtk.Button(label="应用壁纸")
        apply_button.set_valign(Gtk.Align.CENTER)
        apply_button.connect("clicked", self._on_apply_clicked)
        self._status_row.add_suffix(apply_button)

        action_group.add(self._status_row)

    def _build_settings_dialog(self) -> Adw.PreferencesDialog:
        dialog = Adw.PreferencesDialog()
        dialog.set_title("设置")
        dialog.set_content_width(720)
        dialog.set_content_height(520)

        settings_page = Adw.PreferencesPage()
        dialog.add(settings_page)

        source_group = Adw.PreferencesGroup(
            title="壁纸来源",
            description="配置 Steam 安装目录以扫描已下载的 Wallpaper Engine 壁纸。",
        )
        settings_page.add(source_group)

        self._dir_entry = Adw.EntryRow(title="Steam 目录")
        self._dir_entry.set_hexpand(True)
        self._dir_entry.connect("notify::text", self._on_dir_changed)
        browse_button = Gtk.Button(label="浏览…")
        browse_button.set_valign(Gtk.Align.CENTER)
        browse_button.connect("clicked", self._on_browse)
        self._dir_entry.add_suffix(browse_button)
        confirm_button = Gtk.Button(label="确定")
        confirm_button.set_valign(Gtk.Align.CENTER)
        confirm_button.connect("clicked", self._on_set_dir)
        self._dir_entry.add_suffix(confirm_button)
        source_group.add(self._dir_entry)

        overview_group = Adw.PreferencesGroup(
            title="播放说明",
            description="显示器与缩放模式已经保留在主页面，便于切换壁纸时快速调整。",
        )
        settings_page.add(overview_group)

        overview_row = Adw.ActionRow(
            title="niri 概览背景",
            subtitle="请在 niri 配置中单独设置该背景来源。",
        )
        overview_row.set_activatable(False)
        overview_group.add(overview_row)

        return dialog

    def _on_browse(self, _widget) -> None:
        dialog = Gtk.FileDialog(title="选择 Steam 安装目录", modal=True)
        current_dir = Path(self._state.steam_dir_input).expanduser()
        if self._state.steam_dir_input and current_dir.is_dir():
            dialog.set_initial_folder(Gio.File.new_for_path(str(current_dir)))
        dialog.select_folder(self, None, self._on_browse_selected)

    def _on_browse_selected(self, dialog, result) -> None:
        try:
            selected_file = dialog.select_folder_finish(result)
        except GLib.Error:
            return
        selected = selected_file.get_path() if selected_file is not None else None
        if selected is not None:
            self._store.dispatch(SteamDirInputChanged(selected))
            self._store.dispatch(SubmitSteamDir())

    def _on_dir_changed(self, _widget, _pspec=None) -> None:
        self._dispatch_intent(SteamDirInputChanged(self._dir_entry.get_text()))

    def _on_set_dir(self, _widget) -> None:
        self._dispatch_intent(SubmitSteamDir())

    def _on_open_settings(self, _widget) -> None:
        self._settings_dialog.present(self)

    def _on_refresh_monitors(self, _widget) -> None:
        self._dispatch_intent(RefreshMonitors())

    def _on_monitor_changed(self, _widget, _pspec) -> None:
        selected_index = self._monitor_dropdown.get_selected()
        self._dispatch_intent(
            SelectMonitor(
                None if selected_index == 0 else self._monitor_model.get_string(selected_index)
            )
        )

    def _on_scale_changed(self, _widget, _pspec) -> None:
        selected_index = self._scale_dropdown.get_selected()
        if 0 <= selected_index < len(SCALE_MODES):
            self._dispatch_intent(SelectScaling(SCALE_MODES[selected_index]))

    def _on_search_changed(self, _widget) -> None:
        self._dispatch_intent(
            SearchChanged(self._search_entry.get_text().strip()),
            invalidate_filter=True,
        )

    def _filter_func(self, row) -> bool:
        query = self._state.search_query
        if not query or not isinstance(row, WallpaperRow):
            return True
        return row.matches(query)

    def _on_row_selected(self, _listbox, row) -> None:
        directory = row.row_model.directory if isinstance(row, WallpaperRow) else None
        self._dispatch_intent(SelectWallpaper(directory))

    def _on_row_activated(self, _listbox, row) -> None:
        if isinstance(row, WallpaperRow):
            self._dispatch_intent(ApplyWallpaper(row.row_model.directory))

    def _on_apply_clicked(self, _widget) -> None:
        self._dispatch_intent(ApplySelectedWallpaper())

    def _on_start_engine(self, _widget) -> None:
        self._dispatch_intent(StartEngine())

    def _on_stop_engine(self, _widget) -> None:
        self._dispatch_intent(StopEngine())

    def _on_refresh_wallpapers(self, _widget) -> None:
        self._dispatch_intent(RefreshWallpapers())

    def _render(self, state: WallpaperViewState) -> None:
        self._state = state
        # Keep render-triggered widget updates from re-dispatching GTK signals.
        self._rendering = True
        try:
            if self._dir_entry.get_text() != state.steam_dir_input:
                self._dir_entry.set_text(state.steam_dir_input)
            if self._search_entry.get_text() != state.search_query:
                self._search_entry.set_text(state.search_query)

            self._set_monitor_options(state.monitors, state.selected_monitor)

            if state.scaling in SCALE_MODES:
                self._scale_dropdown.set_selected(SCALE_MODES.index(state.scaling))

            if state.wallpaper_rows != self._rendered_wallpapers:
                self._render_wallpaper_rows(state.wallpaper_rows)
            self._sync_selected_row(state.selected_wallpaper_dir)
            self._listbox.invalidate_filter()
            self._status_row.set_subtitle(state.status)
        finally:
            self._rendering = False

    def _render_wallpaper_rows(
        self,
        row_models: tuple[WallpaperRowModel, ...],
    ) -> None:
        self._rendered_wallpapers = row_models
        self._rows_by_directory = {}
        while child := self._listbox.get_first_child():
            self._listbox.remove(child)
        for row_model in row_models:
            row = WallpaperRow(row_model)
            self._rows_by_directory[row_model.directory] = row
            self._listbox.append(row)

    def _sync_selected_row(self, selected_directory) -> None:
        selected_row = self._listbox.get_selected_row()
        if selected_directory is None:
            if selected_row is not None:
                self._listbox.unselect_all()
            return

        target_row = self._rows_by_directory.get(selected_directory)
        if target_row is not None and selected_row is not target_row:
            self._listbox.select_row(target_row)

    def _handle_effect(self, effect: ShowErrorEffect) -> None:
        dialog = Adw.AlertDialog(heading="操作出错", body=effect.message)
        dialog.add_response("ok", "确定")
        dialog.set_default_response("ok")
        dialog.present(self)

    def _dispatch_intent(
        self,
        intent: object,
        *,
        invalidate_filter: bool = False,
    ) -> None:
        if self._rendering:
            return
        self._store.dispatch(intent)
        if invalidate_filter:
            self._listbox.invalidate_filter()

    def _set_monitor_options(
        self,
        monitors: tuple[str, ...],
        selected_monitor: str | None,
    ) -> None:
        values = (AUTO_MONITOR_LABEL, *monitors)
        current_size = self._monitor_model.get_n_items()
        if current_size != len(values):
            self._monitor_model.splice(0, current_size, list(values))
        else:
            for index, value in enumerate(values):
                if self._monitor_model.get_string(index) != value:
                    self._monitor_model.splice(index, 1, [value])

        active_index = 0
        for index, monitor in enumerate(monitors, start=1):
            if monitor == selected_monitor:
                active_index = index
                break
        self._monitor_dropdown.set_selected(active_index)

    def _build_header_title(self) -> Gtk.Box:
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        title_label = Gtk.Label(label=APP_NAME)
        title_label.add_css_class("title")
        title_box.append(title_label)

        subtitle_label = Gtk.Label(label=ENGINE_SUBTITLE)
        subtitle_label.add_css_class("dim-label")
        subtitle_label.add_css_class("caption")
        title_box.append(subtitle_label)

        return title_box
